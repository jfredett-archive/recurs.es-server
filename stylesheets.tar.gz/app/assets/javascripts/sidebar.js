(function ($) {
  $.fn.sidebar = function (options) {
      var $window = $(window);
      var $self = this;
      var $offset = $self.offset();
      var settings = {
        duration: 300,
        easing: "easeInSine",
        padding: 35
      };

      if (options) {
        $.extend(settings,options);  
      }

      return this.each(function () {
          $window.scroll(function () {
            // need to include logic to remove padding if close to footer
            // something like "if scroll bottom < padding, then adjust padding
            // by the difference"
            if ($window.scrollTop() > $offset.top) { 
              $self.stop().animate({
                marginTop: $window.scrollTop() - $offset.top + settings.padding
              }, settings);
            } else {
              $self.stop().animate({
                marginTop: 0
              }, settings);
            }
        })
      });

  }
})(jQuery);


$(function () {
  $('.sidebar').sidebar()
});
